This is an empty archive used to fool homebrew.
